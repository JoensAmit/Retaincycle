//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class person {
    
    let name : String
    init(name :String) {
        self.name = name
    }
    deinit {
        print("\(name) is deinitialized")
    }
}

class Apertment {
    let number: Int
  weak  var teant :person?
    init(number :Int) {
        self.number = number
        var str = "Seemu Apps"
        let vhv = str.getSubString(startindex: 0, endIndex: 5)
    }

}

var bob: person? = person(name: "bob")

let apt:Apertment? = Apertment(number: 123)
apt?.teant = bob
bob = nil
// Present the view controller in the Live View window
//reverse string logic

let string  = "Please Click Here"
let range = (string as NSString).range(of: string, options: .caseInsensitive)
//print(string.count)


extension  String {

  mutating  func getSubString(startindex:Int ,endIndex:Int) -> String {
        
        let startIndex = self.characters.index(self.startIndex, offsetBy: startindex)
        let endIndex = self.characters.index(self.startIndex, offsetBy: endIndex)
        let subString = self[(startIndex ..< endIndex)]
        
        return String(subString)
    }
}



